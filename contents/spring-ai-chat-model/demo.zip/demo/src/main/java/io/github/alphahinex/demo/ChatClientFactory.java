package io.github.alphahinex.demo;

import io.micrometer.common.util.StringUtils;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.openai.OpenAiChatModel;
import org.springframework.ai.openai.OpenAiChatOptions;
import org.springframework.ai.openai.api.OpenAiApi;
import org.springframework.ai.retry.RetryUtils;
import org.springframework.web.client.RestClient;
import org.springframework.web.reactive.function.client.WebClient;

public class ChatClientFactory {

    public static ChatClient createOpenAiChatClient(String baseUrl, String apiKey, String model, String completionsPath) {
        if (StringUtils.isBlank(completionsPath)) {
            completionsPath = "/v1/chat/completions";
        }
        OpenAiApi openAiApi = new OpenAiApi(baseUrl, apiKey, completionsPath,
            "/v1/embeddings", RestClient.builder(), WebClient.builder(), RetryUtils.DEFAULT_RESPONSE_ERROR_HANDLER);
        OpenAiChatModel openAiChatModel = new OpenAiChatModel(openAiApi, OpenAiChatOptions.builder().withModel(model).build());
        return ChatClient.create(openAiChatModel);
    }

}
