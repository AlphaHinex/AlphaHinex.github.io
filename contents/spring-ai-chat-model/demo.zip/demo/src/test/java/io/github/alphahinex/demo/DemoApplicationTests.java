package io.github.alphahinex.demo;

import org.junit.jupiter.api.Test;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoApplicationTests {

	@Autowired
	ChatClient chatClient;

	@Test
	void autoConfig() {
		String userMsg = "who r u";
		System.out.println(chatClient.prompt().user(userMsg).call().content());
	}

	@Test
	void multiClients() {
		ChatClient llm1 = ChatClientFactory.createOpenAiChatClient("https://open.bigmodel.cn/api/paas", "xxxx", "glm-4-flash", "/v4/chat/completions");
		ChatClient llm2 = ChatClientFactory.createOpenAiChatClient("https://open.bigmodel.cn/api/paas", "xxxx", "glm-4-flash", "/v4/chat/completions");

		String userMsg = "你是谁？";
		System.out.println(llm1.prompt().user(userMsg).call().content());
		System.out.println(llm2.prompt().user(userMsg).call().content());
	}

}
