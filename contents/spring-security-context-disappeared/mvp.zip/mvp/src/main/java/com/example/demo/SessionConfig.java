package com.example.demo;

import java.util.concurrent.ConcurrentHashMap;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.session.MapSessionRepository;
import org.springframework.session.Session;
import org.springframework.session.config.annotation.web.http.EnableSpringHttpSession;

/**
 * Spring Session with an in-memory repository.
 * This produces the same SessionRepositoryRequestWrapper$HttpSessionWrapper
 * that the production Redis-backed Spring Session uses.
 */
@Configuration
@EnableSpringHttpSession
public class SessionConfig {

	@Bean
	public MapSessionRepository sessionRepository() {
		MapSessionRepository repository = new MapSessionRepository(new ConcurrentHashMap<String, Session>());
		repository.setDefaultMaxInactiveInterval(1800);
		return repository;
	}
}
