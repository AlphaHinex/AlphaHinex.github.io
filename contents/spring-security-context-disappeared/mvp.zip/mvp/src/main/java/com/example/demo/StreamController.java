package com.example.demo;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Three streaming shapes:
 *
 * /stream/background-first
 *   The request thread does NOT write/flush. The first flush happens on a worker thread.
 *   Spring Security onResponseCommitted() runs on that worker thread, where
 *   SecurityContextHolder is empty, so SPRING_SECURITY_CONTEXT is removed from the session.
 *
 * /stream/request-first
 *   The request thread writes and flushes one frame first. The first commit carries the login
 *   SecurityContext, so the later worker flush does not remove it.
 *
 * /stream/background-first-fixed
 *   Same as background-first, but the request thread calls flushBuffer() first, forcing the
 *   first commit onto the request thread.
 */
@RestController
public class StreamController {

	private final ExecutorService executor = Executors.newCachedThreadPool(r -> {
		Thread thread = new Thread(r);
		thread.setName("stream-worker");
		thread.setDaemon(true);
		return thread;
	});

	@GetMapping("/")
	public String index() {
		return "ok";
	}

	@GetMapping("/me")
	public String me() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication == null) {
			return "anonymous";
		}
		return authentication.getName() + " / " + authentication.getAuthorities();
	}

	/** First response commit happens on the worker thread. */
	@GetMapping(value = "/stream/background-first", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	public void backgroundFirst(HttpServletResponse response) throws Exception {
		response.setContentType("text/event-stream;charset=utf-8");
		ServletOutputStream outputStream = response.getOutputStream();
		// IMPORTANT: no write/flush on the request thread before the worker work.
		runWorker(outputStream);
	}

	/** First response commit happens on the request thread. */
	@GetMapping(value = "/stream/request-first", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	public void requestFirst(HttpServletResponse response) throws Exception {
		response.setContentType("text/event-stream;charset=utf-8");
		ServletOutputStream outputStream = response.getOutputStream();
		outputStream.write("data: first-from-request-thread\n\n".getBytes(StandardCharsets.UTF_8));
		outputStream.flush();
		runWorker(outputStream);
	}

	/** Worker-first, but request thread forces the first commit with flushBuffer(). */
	@GetMapping(value = "/stream/background-first-fixed", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	public void backgroundFirstFixed(HttpServletResponse response) throws Exception {
		response.setContentType("text/event-stream;charset=utf-8");
		ServletOutputStream outputStream = response.getOutputStream();
		response.flushBuffer(); // request thread first commit, carries the login context
		runWorker(outputStream);
	}

	private void runWorker(ServletOutputStream outputStream) throws InterruptedException {
		CountDownLatch latch = new CountDownLatch(1);
		executor.submit(() -> {
			try {
				outputStream.write("data: from-worker-thread\n\n".getBytes(StandardCharsets.UTF_8));
				outputStream.flush();
				outputStream.write("data: [DONE]\n\n".getBytes(StandardCharsets.UTF_8));
				outputStream.flush();
			} catch (IOException e) {
				System.err.println("worker write failed: " + e);
			} finally {
				latch.countDown();
			}
		});
		latch.await();
	}
}

