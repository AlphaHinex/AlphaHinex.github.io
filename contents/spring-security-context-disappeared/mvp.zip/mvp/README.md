# other-thread-clear-spring-security-session

MVP for a session-clearing bug in streaming responses.

Scenario:

> A streaming request completes successfully, but a later protected request returns 403.
> A second streaming shape does not have this problem.

## Why

Spring Security 5.0.x `SaveContextOnUpdateOrErrorResponseWrapper.onResponseCommitted()` saves
`SecurityContextHolder.getContext()` **on the thread that commits the response**.

- request-first path: the request thread writes and flushes one frame first, so the first commit
  carries the login context.
- background-first path: the request thread writes nothing; the first flush comes from a worker
  thread, so the first commit runs without login context.

Then `HttpSessionSecurityContextRepository` removes `SPRING_SECURITY_CONTEXT` from the session,
and the next request is anonymous.

This project uses Spring Boot 2.4.4 with `spring-security.version` pinned to **5.4.3**
(see below) and Spring Session with an in-memory repository, so
`SecurityContextPersistenceFilter`, `HttpSessionSecurityContextRepository` and
`SessionRepositoryRequestWrapper$HttpSessionWrapper` are all active.

## Spring Security version matters

The bug reproduces on Spring Security **5.4.3 and earlier** and is **fixed on 5.4.4 and later**.
The exact boundary is 5.4.3 → 5.4.4.

| Spring Security | `isContextSaved` guard in saveContext | Reproduces |
| --------------- | --------------------------------------- | ---------- |
| 5.0.x – 5.4.3   | present                                 | **yes**    |
| 5.4.4 – 5.8.x   | removed                                 | no         |

**Why the version matters.** `SecurityContextPersistenceFilter.doFilter` 的 finally 块在
`filterChain.doFilter(...)` 返回之后、request 线程上还会执行一次
`repository.saveContext(context, request, response)`。这次 save 携带的是 filter 开头
loadContext 拿到的那个 context——对登录后的请求来说是**完整的认证 context**(不是空的)。

5.0.x–5.4.3 的 `saveContext` 有 `if (!wrapper.isContextSaved())` 守卫。
worker 线程 flush 触发第一次 commit,`onResponseCommitted()` 在 worker 线程上执行
`saveContext`(context 为空),把 `contextSaved` 置为 `true` 并从 session 删掉属性。
之后 request 线程 finally 的 saveContext 被**跳过**——session 属性保持被删状态,下一个请求 403。

5.4.4+ 移除了这个守卫。worker 删掉属性之后,request 线程 finally 的 saveContext **照常执行**,
把登录 context 重新写回 session(日志:`Stored SecurityContextImpl [Authentication=...]`)。
属性保留,下一个请求 200。

> 关键点:5.4.4 不是"不 flush 了",而是"worker 线程删掉属性之后,request 线程还有一次
> saveContext 把登录 context 写回去"。worker 线程确实没有 SecurityContext,它确实删掉了属性,
> 但 5.4.4 的无守卫 saveContext 让 request 线程在 filter 收尾时把属性又补回来了。

> Note: the parent is pinned to Boot **2.4.4** (lowest Boot that manages Security 5.4.x) with
> `<spring-security.version>5.4.3</spring-security.version>` to pin the last reproducing version.
> Boot 2.0.9 (Security 5.0.13) also reproduces the bug.

## Run

Use JDK 11:

~~~bash
export JAVA_HOME=$(/usr/libexec/java_home -v 11)
./mvnw spring-boot:run
~~~

## Reproduce

In another terminal:

~~~bash
BASE=http://localhost:8080

# 1. login, save session cookie
curl -i -c /tmp/background-cookies.txt \
  -d 'username=user&password=password' \
  $BASE/login

# 2. /me is accessible
curl -i -b /tmp/background-cookies.txt $BASE/me

# 3. background-first streaming: first flush happens on the worker thread
curl -N -b /tmp/background-cookies.txt $BASE/stream/background-first

# 4. BUG: /me now returns 403, because SPRING_SECURITY_CONTEXT was removed
curl -i -b /tmp/background-cookies.txt $BASE/me

# 5. login again, then request-first streaming: first flush on the request thread
curl -i -c /tmp/request-cookies.txt \
  -d 'username=user&password=password' \
  $BASE/login
curl -N -b /tmp/request-cookies.txt $BASE/stream/request-first

# 6. OK: /me still returns the logged-in user
curl -i -b /tmp/request-cookies.txt $BASE/me
~~~

## Expected log evidence

For the background-first request, look for:

~~~
SecurityContext is empty or contents are anonymous - context will not be stored in HttpSession.
~~~

and on the next request:

~~~
HttpSession returned null object for SPRING_SECURITY_CONTEXT
No SecurityContext was available from the HttpSession: ...HttpSessionWrapper...
~~~

For the request-first request, the first commit happens on the request thread, so the login context
is saved and `/me` keeps working.

## Verify the proposed fix

The project also exposes `/stream/background-first-fixed`, which calls `response.flushBuffer()` on
the request thread before starting the worker write.

~~~bash
curl -i -c /tmp/fixed-cookies.txt -d 'username=user&password=password' $BASE/login
curl -N -b /tmp/fixed-cookies.txt $BASE/stream/background-first-fixed
curl -i -b /tmp/fixed-cookies.txt $BASE/me
~~~

Expected: `/me` returns 200 and the user, because the first commit now carries the login context.

